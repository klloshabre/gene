import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { ChevronRight, ChevronLeft, CheckCircle2 } from "lucide-react";

interface Question {
  id: string;
  type: "text" | "select" | "radio" | "checkbox" | "textarea";
  question: string;
  options?: string[];
  required?: boolean;
  condition?: {
    questionId: string;
    value: string | string[];
  };
}

interface SmartQuestionnaireProps {
  documentType?: string;
  questions?: Question[][];
  onAnswerChange?: (answers: Record<string, any>) => void;
  onComplete?: (answers: Record<string, any>) => void;
}

const SmartQuestionnaire = ({
  documentType = "Non-Disclosure Agreement",
  questions: providedQuestions,
  onAnswerChange = () => {},
  onComplete = () => {},
}: SmartQuestionnaireProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});

  // Use provided questions or fall back to default NDA questions
  const defaultQuestions: Question[][] = [
    // Step 1: Basic Information
    [
      {
        id: "partyName",
        type: "text",
        question: "What is your company name?",
        required: true,
      },
      {
        id: "counterpartyName",
        type: "text",
        question: "What is the other party's name?",
        required: true,
      },
    ],
    // Step 2: Location Information
    [
      {
        id: "state",
        type: "select",
        question: "Which state's law will govern this agreement?",
        options: ["California", "New York", "Texas", "Florida", "Delaware"],
        required: true,
      },
      {
        id: "businessType",
        type: "select",
        question: "What type of business are you?",
        options: [
          "Corporation",
          "LLC",
          "Partnership",
          "Sole Proprietorship",
          "Non-profit",
        ],
        required: true,
      },
    ],
    // Step 3: Contract Purpose
    [
      {
        id: "purpose",
        type: "radio",
        question: "What is the primary purpose of this agreement?",
        options: [
          "Business Discussion",
          "Product Development",
          "Investment Opportunity",
          "Employment",
          "Other",
        ],
        required: true,
      },
      {
        id: "purposeOther",
        type: "text",
        question: "Please specify the purpose:",
        condition: {
          questionId: "purpose",
          value: "Other",
        },
      },
    ],
    // Step 4: Specific Terms
    [
      {
        id: "duration",
        type: "select",
        question: "How long should the confidentiality obligations last?",
        options: ["1 year", "2 years", "3 years", "5 years", "Indefinitely"],
        required: true,
      },
      {
        id: "exclusions",
        type: "checkbox",
        question: "Select any standard exclusions to confidentiality:",
        options: [
          "Publicly available information",
          "Information known prior to disclosure",
          "Information independently developed",
          "Information rightfully received from third parties",
        ],
      },
    ],
    // Step 5: Additional Information
    [
      {
        id: "additionalTerms",
        type: "textarea",
        question: "Any additional terms or special considerations?",
      },
    ],
  ];

  const questions = providedQuestions || defaultQuestions;

  const totalSteps = questions.length;
  const progress = ((currentStep + 1) / totalSteps) * 100;

  const handleAnswerChange = (questionId: string, value: any) => {
    const newAnswers = { ...answers, [questionId]: value };
    setAnswers(newAnswers);
    onAnswerChange(newAnswers);
  };

  const handleNext = () => {
    // Validate current step
    const currentQuestions = questions[currentStep];
    const visibleQuestions = currentQuestions.filter(shouldShowQuestion);

    const isValid = visibleQuestions.every((q) => {
      if (q.required && (!answers[q.id] || answers[q.id] === "")) {
        return false;
      }
      return true;
    });

    if (!isValid) {
      // Show validation error
      alert("Please answer all required questions before proceeding.");
      return;
    }

    if (currentStep < totalSteps - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Questionnaire complete - trigger the completion handler
      console.log("Triggering onComplete with answers:", answers);
      onComplete(answers);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const shouldShowQuestion = (question: Question): boolean => {
    if (!question.condition) return true;

    const { questionId, value } = question.condition;
    const answer = answers[questionId];

    if (Array.isArray(value)) {
      return value.includes(answer);
    }

    return answer === value;
  };

  const renderQuestion = (question: Question) => {
    if (!shouldShowQuestion(question)) return null;

    switch (question.type) {
      case "text":
        return (
          <div className="space-y-2" key={question.id}>
            <Label htmlFor={question.id}>
              {question.question}{" "}
              {question.required && <span className="text-red-500">*</span>}
            </Label>
            <Input
              id={question.id}
              value={answers[question.id] || ""}
              onChange={(e) => handleAnswerChange(question.id, e.target.value)}
              placeholder="Type your answer here"
            />
          </div>
        );

      case "select":
        return (
          <div className="space-y-2" key={question.id}>
            <Label htmlFor={question.id}>
              {question.question}{" "}
              {question.required && <span className="text-red-500">*</span>}
            </Label>
            <Select
              value={answers[question.id] || ""}
              onValueChange={(value) => handleAnswerChange(question.id, value)}
            >
              <SelectTrigger id={question.id}>
                <SelectValue placeholder="Select an option" />
              </SelectTrigger>
              <SelectContent>
                {question.options?.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );

      case "radio":
        return (
          <div className="space-y-2" key={question.id}>
            <Label>
              {question.question}{" "}
              {question.required && <span className="text-red-500">*</span>}
            </Label>
            <RadioGroup
              value={answers[question.id] || ""}
              onValueChange={(value) => handleAnswerChange(question.id, value)}
            >
              {question.options?.map((option) => (
                <div className="flex items-center space-x-2" key={option}>
                  <RadioGroupItem
                    value={option}
                    id={`${question.id}-${option}`}
                  />
                  <Label htmlFor={`${question.id}-${option}`}>{option}</Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        );

      case "checkbox":
        return (
          <div className="space-y-2" key={question.id}>
            <Label>
              {question.question}{" "}
              {question.required && <span className="text-red-500">*</span>}
            </Label>
            <div className="space-y-2">
              {question.options?.map((option) => {
                const selectedOptions = answers[question.id] || [];
                return (
                  <div className="flex items-center space-x-2" key={option}>
                    <Checkbox
                      id={`${question.id}-${option}`}
                      checked={selectedOptions.includes(option)}
                      onCheckedChange={(checked) => {
                        const currentSelected = answers[question.id] || [];
                        let newSelected;
                        if (checked) {
                          newSelected = [...currentSelected, option];
                        } else {
                          newSelected = currentSelected.filter(
                            (item: string) => item !== option,
                          );
                        }
                        handleAnswerChange(question.id, newSelected);
                      }}
                    />
                    <Label htmlFor={`${question.id}-${option}`}>{option}</Label>
                  </div>
                );
              })}
            </div>
          </div>
        );

      case "textarea":
        return (
          <div className="space-y-2" key={question.id}>
            <Label htmlFor={question.id}>
              {question.question}{" "}
              {question.required && <span className="text-red-500">*</span>}
            </Label>
            <Textarea
              id={question.id}
              value={answers[question.id] || ""}
              onChange={(e) => handleAnswerChange(question.id, e.target.value)}
              placeholder="Type your answer here"
              rows={4}
            />
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Card className="w-full bg-white shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>{documentType} - Questionnaire</span>
          <span className="text-sm font-normal text-muted-foreground">
            Step {currentStep + 1} of {totalSteps}
          </span>
        </CardTitle>
        <Progress value={progress} className="h-2" />
      </CardHeader>
      <CardContent className="space-y-6">
        {questions[currentStep].map((question) => renderQuestion(question))}

        <div className="flex justify-between pt-4">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStep === 0}
          >
            <ChevronLeft className="mr-2 h-4 w-4" /> Previous
          </Button>

          <Button onClick={handleNext}>
            {currentStep === totalSteps - 1 ? (
              <>
                Complete <CheckCircle2 className="ml-2 h-4 w-4" />
              </>
            ) : (
              <>
                Next <ChevronRight className="ml-2 h-4 w-4" />
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default SmartQuestionnaire;
