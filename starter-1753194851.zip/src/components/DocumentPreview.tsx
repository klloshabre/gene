import React from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Info } from "lucide-react";

interface ClauseExplanation {
  id: string;
  text: string;
  explanation: string;
}

interface DocumentPreviewProps {
  documentContent?: string;
  missingFields?: string[];
  clauses?: ClauseExplanation[];
  documentTitle?: string;
}

const DocumentPreview = ({
  documentContent = "<p>Your document preview will appear here as you complete the questionnaire.</p>",
  missingFields = [],
  clauses = [
    {
      id: "clause-1",
      text: "Indemnification",
      explanation:
        "This clause protects one party from financial loss caused by the actions of another party.",
    },
    {
      id: "clause-2",
      text: "Force Majeure",
      explanation:
        "This clause excuses a party from liability if some unforeseen event prevents them from performing their obligations.",
    },
  ],
  documentTitle = "Document Preview",
}: DocumentPreviewProps) => {
  // Function to highlight missing fields in the document
  const highlightMissingFields = (content: string) => {
    let highlightedContent = content;
    missingFields.forEach((field) => {
      const regex = new RegExp(`\\[${field}\\]`, "g");
      highlightedContent = highlightedContent.replace(
        regex,
        `<span class="bg-yellow-100 text-yellow-800 px-1 rounded">[${field}]</span>`,
      );
    });
    return highlightedContent;
  };

  // Function to add tooltips to legal clauses
  const addClauseTooltips = (content: string) => {
    let contentWithTooltips = content;
    clauses.forEach((clause) => {
      const regex = new RegExp(`(${clause.text})`, "g");
      contentWithTooltips = contentWithTooltips.replace(
        regex,
        `<span class="relative inline-block cursor-help border-b border-dotted border-gray-400" data-clause-id="${clause.id}">${clause.text}<span class="clause-tooltip hidden absolute bottom-full left-1/2 transform -translate-x-1/2 bg-black text-white text-xs rounded p-2 w-64 z-10">${clause.explanation}</span></span>`,
      );
    });
    return contentWithTooltips;
  };

  // Process the document content with highlighting and tooltips
  const processedContent = addClauseTooltips(
    highlightMissingFields(documentContent),
  );

  return (
    <div className="bg-white h-full flex flex-col">
      <div className="p-4 border-b">
        <h2 className="text-xl font-semibold flex items-center">
          {documentTitle}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="ml-2 h-4 w-4 text-gray-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent>
                <p className="w-64">
                  This is a real-time preview of your document. Hover over
                  highlighted legal terms for explanations.
                </p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </h2>
      </div>

      <ScrollArea className="flex-grow">
        <Card className="m-4 border shadow-sm">
          <CardContent className="p-6">
            <div
              className="prose max-w-none"
              dangerouslySetInnerHTML={{ __html: processedContent }}
            />
          </CardContent>
        </Card>
      </ScrollArea>

      {missingFields.length > 0 && (
        <div className="p-4 border-t bg-gray-50">
          <p className="text-sm text-gray-600 flex items-center">
            <Info className="mr-2 h-4 w-4 text-amber-500" />
            {missingFields.length} field(s) need to be completed
          </p>
        </div>
      )}
    </div>
  );
};

export default DocumentPreview;
