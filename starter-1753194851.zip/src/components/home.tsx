import React, { useState } from "react";
import DocumentTypeSelector from "./DocumentTypeSelector";
import SmartQuestionnaire from "./SmartQuestionnaire";
import DocumentPreview from "./DocumentPreview";
import { Separator } from "./ui/separator";
import { Card, CardContent } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Button } from "./ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { ArrowLeft, Save, Download, Share2, FileText } from "lucide-react";

interface DocumentType {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
}

interface QuestionnaireData {
  state?: string;
  businessType?: string;
  contractPurpose?: string;
  [key: string]: any;
}

interface DocumentConfig {
  title: string;
  description: string;
  questions: any[][];
  generateContent: (data: QuestionnaireData) => string;
  getMissingFields: (data: QuestionnaireData) => string[];
}

const Home = () => {
  const [selectedDocType, setSelectedDocType] = useState<DocumentType | null>(
    null,
  );
  const [questionnaireData, setQuestionnaireData] = useState<QuestionnaireData>(
    {},
  );
  const [activeView, setActiveView] = useState<
    "split" | "questionnaire" | "preview"
  >("split");
  const [progress, setProgress] = useState<number>(0);
  const [isDownloadDialogOpen, setIsDownloadDialogOpen] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState<string>("");

  // Document-specific configurations
  const documentConfigs: Record<string, DocumentConfig> = {
    nda: {
      title: "Non-Disclosure Agreement",
      description:
        "Protect confidential information when sharing with partners or employees",
      questions: [
        // Step 1: Basic Information
        [
          {
            id: "partyName",
            type: "text",
            question: "What is your company name?",
            required: true,
          },
          {
            id: "counterpartyName",
            type: "text",
            question: "What is the other party's name?",
            required: true,
          },
        ],
        // Step 2: Location Information
        [
          {
            id: "state",
            type: "select",
            question: "Which state's law will govern this agreement?",
            options: ["California", "New York", "Texas", "Florida", "Delaware"],
            required: true,
          },
          {
            id: "businessType",
            type: "select",
            question: "What type of business are you?",
            options: [
              "Corporation",
              "LLC",
              "Partnership",
              "Sole Proprietorship",
              "Non-profit",
            ],
            required: true,
          },
        ],
        // Step 3: Contract Purpose
        [
          {
            id: "purpose",
            type: "radio",
            question: "What is the primary purpose of this agreement?",
            options: [
              "Business Discussion",
              "Product Development",
              "Investment Opportunity",
              "Employment",
              "Other",
            ],
            required: true,
          },
          {
            id: "purposeOther",
            type: "text",
            question: "Please specify the purpose:",
            condition: {
              questionId: "purpose",
              value: "Other",
            },
          },
        ],
        // Step 4: Specific Terms
        [
          {
            id: "duration",
            type: "select",
            question: "How long should the confidentiality obligations last?",
            options: [
              "1 year",
              "2 years",
              "3 years",
              "5 years",
              "Indefinitely",
            ],
            required: true,
          },
          {
            id: "exclusions",
            type: "checkbox",
            question: "Select any standard exclusions to confidentiality:",
            options: [
              "Publicly available information",
              "Information known prior to disclosure",
              "Information independently developed",
              "Information rightfully received from third parties",
            ],
          },
        ],
        // Step 5: Additional Information
        [
          {
            id: "additionalTerms",
            type: "textarea",
            question: "Any additional terms or special considerations?",
          },
        ],
      ],
      generateContent: (data: QuestionnaireData) => {
        const {
          partyName,
          counterpartyName,
          state,
          businessType,
          purpose,
          duration,
          exclusions,
          additionalTerms,
        } = data;

        return `
          <h1>NON-DISCLOSURE AGREEMENT</h1>
          
          <p>This Non-Disclosure Agreement ("Agreement") is entered into on [DATE] between:</p>
          
          <p><strong>Party 1:</strong> ${partyName || "[PARTY_NAME]"}</p>
          <p><strong>Party 2:</strong> ${counterpartyName || "[COUNTERPARTY_NAME]"}</p>
          
          <h2>1. Purpose</h2>
          <p>The purpose of this agreement is for: ${purpose || "[PURPOSE]"}</p>
          
          <h2>2. Confidential Information</h2>
          <p>For purposes of this Agreement, "Confidential Information" means any and all non-public, confidential or proprietary information disclosed by either party.</p>
          
          <h2>3. Obligations</h2>
          <p>Each party agrees to:</p>
          <ul>
            <li>Hold and maintain the Confidential Information in strict confidence</li>
            <li>Not disclose the Confidential Information to third parties</li>
            <li>Use the Confidential Information solely for the stated purpose</li>
          </ul>
          
          <h2>4. Duration</h2>
          <p>This agreement shall remain in effect for: ${duration || "[DURATION]"}</p>
          
          ${
            exclusions && exclusions.length > 0
              ? `
          <h2>5. Exclusions</h2>
          <p>The following information is excluded from confidentiality obligations:</p>
          <ul>
            ${exclusions.map((exclusion: string) => `<li>${exclusion}</li>`).join("")}
          </ul>
          `
              : ""
          }
          
          <h2>6. Governing Law</h2>
          <p>This Agreement shall be governed by the laws of ${state || "[STATE]"}.</p>
          
          ${
            additionalTerms
              ? `
          <h2>7. Additional Terms</h2>
          <p>${additionalTerms}</p>
          `
              : ""
          }
          
          <p><strong>Business Type:</strong> ${businessType || "[BUSINESS_TYPE]"}</p>
          
          <div style="margin-top: 40px;">
            <p>_________________________</p>
            <p>${partyName || "[PARTY_NAME]"}</p>
            <p>Date: ___________</p>
            
            <br>
            
            <p>_________________________</p>
            <p>${counterpartyName || "[COUNTERPARTY_NAME]"}</p>
            <p>Date: ___________</p>
          </div>
        `;
      },
      getMissingFields: (data: QuestionnaireData) => {
        const requiredFields = [
          "partyName",
          "counterpartyName",
          "state",
          "businessType",
          "purpose",
          "duration",
        ];
        return requiredFields.filter(
          (field) => !data[field] || data[field] === "",
        );
      },
    },
    "employment-contract": {
      title: "Employment Contract",
      description:
        "Create legally compliant employment agreements for new hires",
      questions: [
        // Step 1: Employee Information
        [
          {
            id: "employeeName",
            type: "text",
            question: "Employee's full name:",
            required: true,
          },
          {
            id: "employeeAddress",
            type: "textarea",
            question: "Employee's address:",
            required: true,
          },
        ],
        // Step 2: Employer Information
        [
          {
            id: "companyName",
            type: "text",
            question: "Company name:",
            required: true,
          },
          {
            id: "companyAddress",
            type: "textarea",
            question: "Company address:",
            required: true,
          },
          {
            id: "state",
            type: "select",
            question: "Which state's employment law will govern this contract?",
            options: ["California", "New York", "Texas", "Florida", "Delaware"],
            required: true,
          },
        ],
        // Step 3: Position Details
        [
          {
            id: "jobTitle",
            type: "text",
            question: "Job title:",
            required: true,
          },
          {
            id: "department",
            type: "text",
            question: "Department:",
            required: true,
          },
          {
            id: "startDate",
            type: "text",
            question: "Start date (MM/DD/YYYY):",
            required: true,
          },
          {
            id: "employmentType",
            type: "radio",
            question: "Employment type:",
            options: ["Full-time", "Part-time", "Contract", "Temporary"],
            required: true,
          },
        ],
        // Step 4: Compensation
        [
          {
            id: "salary",
            type: "text",
            question: "Annual salary (USD):",
            required: true,
          },
          {
            id: "payFrequency",
            type: "select",
            question: "Pay frequency:",
            options: ["Weekly", "Bi-weekly", "Monthly", "Semi-monthly"],
            required: true,
          },
          {
            id: "benefits",
            type: "checkbox",
            question: "Select applicable benefits:",
            options: [
              "Health Insurance",
              "Dental Insurance",
              "Vision Insurance",
              "401(k) Plan",
              "Paid Time Off",
              "Life Insurance",
            ],
          },
        ],
        // Step 5: Terms and Conditions
        [
          {
            id: "probationPeriod",
            type: "select",
            question: "Probation period:",
            options: ["None", "30 days", "60 days", "90 days", "6 months"],
            required: true,
          },
          {
            id: "terminationNotice",
            type: "select",
            question: "Required notice period for termination:",
            options: ["None", "1 week", "2 weeks", "30 days", "60 days"],
            required: true,
          },
          {
            id: "nonCompete",
            type: "radio",
            question: "Include non-compete clause?",
            options: ["Yes", "No"],
            required: true,
          },
          {
            id: "nonCompeteDuration",
            type: "select",
            question: "Non-compete duration:",
            options: ["6 months", "1 year", "2 years"],
            condition: {
              questionId: "nonCompete",
              value: "Yes",
            },
          },
        ],
      ],
      generateContent: (data: QuestionnaireData) => {
        const {
          employeeName,
          employeeAddress,
          companyName,
          companyAddress,
          state,
          jobTitle,
          department,
          startDate,
          employmentType,
          salary,
          payFrequency,
          benefits,
          probationPeriod,
          terminationNotice,
          nonCompete,
          nonCompeteDuration,
        } = data;

        return `
          <h1>EMPLOYMENT CONTRACT</h1>
          
          <p>This Employment Agreement ("Agreement") is entered into on [DATE] between:</p>
          
          <p><strong>Employer:</strong> ${companyName || "[COMPANY_NAME]"}<br>
          Address: ${companyAddress || "[COMPANY_ADDRESS]"}</p>
          
          <p><strong>Employee:</strong> ${employeeName || "[EMPLOYEE_NAME]"}<br>
          Address: ${employeeAddress || "[EMPLOYEE_ADDRESS]"}</p>
          
          <h2>1. Position and Duties</h2>
          <p>The Employee is hired as <strong>${jobTitle || "[JOB_TITLE]"}</strong> in the ${department || "[DEPARTMENT]"} department.</p>
          <p>Employment Type: <strong>${employmentType || "[EMPLOYMENT_TYPE]"}</strong></p>
          <p>Start Date: <strong>${startDate || "[START_DATE]"}</strong></p>
          
          <h2>2. Compensation</h2>
          <p>Annual Salary: <strong>${salary || "[SALARY]"}</strong></p>
          <p>Pay Frequency: <strong>${payFrequency || "[PAY_FREQUENCY]"}</strong></p>
          
          ${
            benefits && benefits.length > 0
              ? `
          <h2>3. Benefits</h2>
          <p>The Employee is eligible for the following benefits:</p>
          <ul>
            ${benefits.map((benefit: string) => `<li>${benefit}</li>`).join("")}
          </ul>
          `
              : ""
          }
          
          <h2>4. Employment Terms</h2>
          <p>Probation Period: <strong>${probationPeriod || "[PROBATION_PERIOD]"}</strong></p>
          <p>Termination Notice: <strong>${terminationNotice || "[TERMINATION_NOTICE]"}</strong></p>
          
          ${
            nonCompete === "Yes"
              ? `
          <h2>5. Non-Compete Agreement</h2>
          <p>The Employee agrees not to engage in competing business activities for a period of <strong>${nonCompeteDuration || "[NON_COMPETE_DURATION]"}</strong> following termination of employment.</p>
          `
              : ""
          }
          
          <h2>6. Confidentiality</h2>
          <p>The Employee agrees to maintain the confidentiality of all proprietary information and trade secrets of the Company.</p>
          
          <h2>7. Governing Law</h2>
          <p>This Agreement shall be governed by the employment laws of ${state || "[STATE]"}.</p>
          
          <div style="margin-top: 40px;">
            <p>_________________________</p>
            <p>${companyName || "[COMPANY_NAME]"}</p>
            <p>Employer Signature</p>
            <p>Date: ___________</p>
            
            <br>
            
            <p>_________________________</p>
            <p>${employeeName || "[EMPLOYEE_NAME]"}</p>
            <p>Employee Signature</p>
            <p>Date: ___________</p>
          </div>
        `;
      },
      getMissingFields: (data: QuestionnaireData) => {
        const requiredFields = [
          "employeeName",
          "employeeAddress",
          "companyName",
          "companyAddress",
          "state",
          "jobTitle",
          "department",
          "startDate",
          "employmentType",
          "salary",
          "payFrequency",
          "probationPeriod",
          "terminationNotice",
          "nonCompete",
        ];
        return requiredFields.filter(
          (field) => !data[field] || data[field] === "",
        );
      },
    },
    "service-agreement": {
      title: "Service Agreement",
      description:
        "Define terms and conditions for providing services to clients",
      questions: [
        // Step 1: Service Provider Information
        [
          {
            id: "providerName",
            type: "text",
            question: "Service provider name:",
            required: true,
          },
          {
            id: "providerAddress",
            type: "textarea",
            question: "Service provider address:",
            required: true,
          },
        ],
        // Step 2: Client Information
        [
          {
            id: "clientName",
            type: "text",
            question: "Client name:",
            required: true,
          },
          {
            id: "clientAddress",
            type: "textarea",
            question: "Client address:",
            required: true,
          },
          {
            id: "state",
            type: "select",
            question: "Which state's law will govern this agreement?",
            options: ["California", "New York", "Texas", "Florida", "Delaware"],
            required: true,
          },
        ],
        // Step 3: Service Details
        [
          {
            id: "serviceDescription",
            type: "textarea",
            question: "Detailed description of services to be provided:",
            required: true,
          },
          {
            id: "serviceType",
            type: "select",
            question: "Type of service:",
            options: [
              "Consulting",
              "Design",
              "Development",
              "Marketing",
              "Legal",
              "Accounting",
              "Other",
            ],
            required: true,
          },
        ],
        // Step 4: Timeline and Deliverables
        [
          {
            id: "startDate",
            type: "text",
            question: "Project start date (MM/DD/YYYY):",
            required: true,
          },
          {
            id: "endDate",
            type: "text",
            question: "Project end date (MM/DD/YYYY):",
            required: true,
          },
          {
            id: "deliverables",
            type: "textarea",
            question: "List key deliverables:",
            required: true,
          },
        ],
        // Step 5: Payment Terms
        [
          {
            id: "totalAmount",
            type: "text",
            question: "Total project amount (USD):",
            required: true,
          },
          {
            id: "paymentSchedule",
            type: "radio",
            question: "Payment schedule:",
            options: [
              "Full payment upfront",
              "50% upfront, 50% on completion",
              "Monthly payments",
              "Payment on milestones",
              "Payment on completion",
            ],
            required: true,
          },
          {
            id: "paymentTerms",
            type: "select",
            question: "Payment terms:",
            options: ["Net 15", "Net 30", "Net 45", "Net 60"],
            required: true,
          },
        ],
      ],
      generateContent: (data: QuestionnaireData) => {
        const {
          providerName,
          providerAddress,
          clientName,
          clientAddress,
          state,
          serviceDescription,
          serviceType,
          startDate,
          endDate,
          deliverables,
          totalAmount,
          paymentSchedule,
          paymentTerms,
        } = data;

        return `
          <h1>SERVICE AGREEMENT</h1>
          
          <p>This Service Agreement ("Agreement") is entered into on [DATE] between:</p>
          
          <p><strong>Service Provider:</strong> ${providerName || "[PROVIDER_NAME]"}<br>
          Address: ${providerAddress || "[PROVIDER_ADDRESS]"}</p>
          
          <p><strong>Client:</strong> ${clientName || "[CLIENT_NAME]"}<br>
          Address: ${clientAddress || "[CLIENT_ADDRESS]"}</p>
          
          <h2>1. Services</h2>
          <p>Service Type: <strong>${serviceType || "[SERVICE_TYPE]"}</strong></p>
          <p>Description: ${serviceDescription || "[SERVICE_DESCRIPTION]"}</p>
          
          <h2>2. Timeline</h2>
          <p>Start Date: <strong>${startDate || "[START_DATE]"}</strong></p>
          <p>End Date: <strong>${endDate || "[END_DATE]"}</strong></p>
          
          <h2>3. Deliverables</h2>
          <p>${deliverables || "[DELIVERABLES]"}</p>
          
          <h2>4. Compensation</h2>
          <p>Total Amount: <strong>${totalAmount || "[TOTAL_AMOUNT]"}</strong></p>
          <p>Payment Schedule: <strong>${paymentSchedule || "[PAYMENT_SCHEDULE]"}</strong></p>
          <p>Payment Terms: <strong>${paymentTerms || "[PAYMENT_TERMS]"}</strong></p>
          
          <h2>5. Intellectual Property</h2>
          <p>All work products created under this Agreement shall be owned by the Client upon full payment.</p>
          
          <h2>6. Confidentiality</h2>
          <p>Both parties agree to maintain confidentiality of proprietary information shared during the course of this engagement.</p>
          
          <h2>7. Termination</h2>
          <p>Either party may terminate this Agreement with 30 days written notice.</p>
          
          <h2>8. Governing Law</h2>
          <p>This Agreement shall be governed by the laws of ${state || "[STATE]"}.</p>
          
          <div style="margin-top: 40px;">
            <p>_________________________</p>
            <p>${providerName || "[PROVIDER_NAME]"}</p>
            <p>Service Provider Signature</p>
            <p>Date: ___________</p>
            
            <br>
            
            <p>_________________________</p>
            <p>${clientName || "[CLIENT_NAME]"}</p>
            <p>Client Signature</p>
            <p>Date: ___________</p>
          </div>
        `;
      },
      getMissingFields: (data: QuestionnaireData) => {
        const requiredFields = [
          "providerName",
          "providerAddress",
          "clientName",
          "clientAddress",
          "state",
          "serviceDescription",
          "serviceType",
          "startDate",
          "endDate",
          "deliverables",
          "totalAmount",
          "paymentSchedule",
          "paymentTerms",
        ];
        return requiredFields.filter(
          (field) => !data[field] || data[field] === "",
        );
      },
    },
    "operating-agreement": {
      title: "Operating Agreement",
      description:
        "Establish rules and structure for your LLC or business entity",
      questions: [
        // Step 1: LLC Information
        [
          {
            id: "llcName",
            type: "text",
            question: "LLC name:",
            required: true,
          },
          {
            id: "state",
            type: "select",
            question: "State of formation:",
            options: ["California", "New York", "Texas", "Florida", "Delaware"],
            required: true,
          },
          {
            id: "formationDate",
            type: "text",
            question: "Date of formation (MM/DD/YYYY):",
            required: true,
          },
        ],
        // Step 2: Members
        [
          {
            id: "numberOfMembers",
            type: "select",
            question: "Number of members:",
            options: ["1", "2", "3", "4", "5+"],
            required: true,
          },
          {
            id: "memberNames",
            type: "textarea",
            question: "List all member names (one per line):",
            required: true,
          },
        ],
        // Step 3: Management Structure
        [
          {
            id: "managementType",
            type: "radio",
            question: "Management structure:",
            options: ["Member-managed", "Manager-managed"],
            required: true,
          },
          {
            id: "managerName",
            type: "text",
            question: "Manager name:",
            condition: {
              questionId: "managementType",
              value: "Manager-managed",
            },
          },
        ],
        // Step 4: Capital Contributions
        [
          {
            id: "initialCapital",
            type: "text",
            question: "Total initial capital contribution (USD):",
            required: true,
          },
          {
            id: "capitalContributions",
            type: "textarea",
            question: "List each member's capital contribution (Name: Amount):",
            required: true,
          },
        ],
        // Step 5: Profit and Loss Distribution
        [
          {
            id: "distributionMethod",
            type: "radio",
            question: "How will profits and losses be distributed?",
            options: [
              "Equal distribution among all members",
              "Based on capital contributions",
              "Custom percentages",
            ],
            required: true,
          },
          {
            id: "customDistribution",
            type: "textarea",
            question:
              "Specify custom distribution percentages (Name: Percentage):",
            condition: {
              questionId: "distributionMethod",
              value: "Custom percentages",
            },
          },
        ],
      ],
      generateContent: (data: QuestionnaireData) => {
        const {
          llcName,
          state,
          formationDate,
          numberOfMembers,
          memberNames,
          managementType,
          managerName,
          initialCapital,
          capitalContributions,
          distributionMethod,
          customDistribution,
        } = data;

        return `
          <h1>OPERATING AGREEMENT</h1>
          <h2>FOR ${llcName || "[LLC_NAME]"}</h2>
          
          <p>This Operating Agreement ("Agreement") is entered into on [DATE] for <strong>${llcName || "[LLC_NAME]"}</strong>, a Limited Liability Company formed under the laws of ${state || "[STATE]"}.</p>
          
          <h2>1. Formation</h2>
          <p>LLC Name: <strong>${llcName || "[LLC_NAME]"}</strong></p>
          <p>State of Formation: <strong>${state || "[STATE]"}</strong></p>
          <p>Date of Formation: <strong>${formationDate || "[FORMATION_DATE]"}</strong></p>
          
          <h2>2. Members</h2>
          <p>Number of Members: <strong>${numberOfMembers || "[NUMBER_OF_MEMBERS]"}</strong></p>
          <p>Member Names:</p>
          <pre>${memberNames || "[MEMBER_NAMES]"}</pre>
          
          <h2>3. Management</h2>
          <p>Management Structure: <strong>${managementType || "[MANAGEMENT_TYPE]"}</strong></p>
          ${
            managementType === "Manager-managed"
              ? `<p>Manager: <strong>${managerName || "[MANAGER_NAME]"}</strong></p>`
              : ""
          }
          
          <h2>4. Capital Contributions</h2>
          <p>Total Initial Capital: <strong>${initialCapital || "[INITIAL_CAPITAL]"}</strong></p>
          <p>Individual Contributions:</p>
          <pre>${capitalContributions || "[CAPITAL_CONTRIBUTIONS]"}</pre>
          
          <h2>5. Profit and Loss Distribution</h2>
          <p>Distribution Method: <strong>${distributionMethod || "[DISTRIBUTION_METHOD]"}</strong></p>
          ${
            distributionMethod === "Custom percentages"
              ? `<p>Custom Distribution:</p><pre>${customDistribution || "[CUSTOM_DISTRIBUTION]"}</pre>`
              : ""
          }
          
          <h2>6. Meetings</h2>
          <p>Annual meetings of members shall be held to discuss the business and affairs of the LLC.</p>
          
          <h2>7. Transfer of Interests</h2>
          <p>No member may transfer their interest in the LLC without the written consent of all other members.</p>
          
          <h2>8. Dissolution</h2>
          <p>The LLC may be dissolved by unanimous consent of all members or as otherwise provided by law.</p>
          
          <h2>9. Governing Law</h2>
          <p>This Agreement shall be governed by the laws of ${state || "[STATE]"}.</p>
          
          <div style="margin-top: 40px;">
            <p><strong>Member Signatures:</strong></p>
            <br>
            <p>_________________________</p>
            <p>Member Name</p>
            <p>Date: ___________</p>
            
            <br>
            
            <p>_________________________</p>
            <p>Member Name</p>
            <p>Date: ___________</p>
          </div>
        `;
      },
      getMissingFields: (data: QuestionnaireData) => {
        const requiredFields = [
          "llcName",
          "state",
          "formationDate",
          "numberOfMembers",
          "memberNames",
          "managementType",
          "initialCapital",
          "capitalContributions",
          "distributionMethod",
        ];
        return requiredFields.filter(
          (field) => !data[field] || data[field] === "",
        );
      },
    },
  };

  const handleDocTypeSelect = (docTypeId: string) => {
    const config = documentConfigs[docTypeId];
    if (config) {
      const docType = {
        id: docTypeId,
        title: config.title,
        description: config.description,
        icon: null,
      };
      setSelectedDocType(docType);
      setQuestionnaireData({});
      setProgress(0);
    }
  };

  const handleQuestionnaireUpdate = (data: QuestionnaireData) => {
    setQuestionnaireData(data);

    // Calculate progress based on filled fields
    const totalFields = Object.keys(data).length;
    const filledFields = Object.values(data).filter(
      (value) =>
        value !== undefined &&
        value !== "" &&
        value !== null &&
        (Array.isArray(value) ? value.length > 0 : true),
    ).length;
    setProgress(totalFields > 0 ? (filledFields / totalFields) * 100 : 0);
  };

  const handleQuestionnaireComplete = (data: QuestionnaireData) => {
    setQuestionnaireData(data);
    setProgress(100);
    console.log("Questionnaire completed with data:", data);

    // Show completion message
    alert("Questionnaire completed! You can now download your document.");
  };

  const handleBack = () => {
    setSelectedDocType(null);
    setQuestionnaireData({});
    setProgress(0);
  };

  const generateDocumentContent = (data: QuestionnaireData) => {
    if (Object.keys(data).length === 0) {
      return "<p>Your document preview will appear here as you complete the questionnaire.</p>";
    }

    if (selectedDocType) {
      const config = documentConfigs[selectedDocType.id];
      if (config) {
        return config.generateContent(data);
      }
    }

    return "<p>Document configuration not found.</p>";
  };

  const getMissingFields = (data: QuestionnaireData) => {
    if (selectedDocType) {
      const config = documentConfigs[selectedDocType.id];
      if (config) {
        return config.getMissingFields(data);
      }
    }
    return [];
  };

  const handleDownload = () => {
    if (!selectedFormat) {
      alert("Please select a format to download.");
      return;
    }

    const missingFields = getMissingFields(questionnaireData);
    if (missingFields.length > 0) {
      alert(
        `Please complete the following fields before downloading: ${missingFields.join(", ")}`,
      );
      return;
    }

    const documentContent = generateDocumentContent(questionnaireData);
    const documentTitle = selectedDocType?.title || "Document";

    if (selectedFormat === "pdf") {
      // For PDF download - create a printable version
      const printWindow = window.open("", "_blank");
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>${documentTitle}</title>
              <style>
                body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
                h1, h2 { color: #333; }
                .signature-section { margin-top: 40px; }
              </style>
            </head>
            <body>
              ${documentContent}
              <script>window.print(); window.close();</script>
            </body>
          </html>
        `);
        printWindow.document.close();
      }
    } else if (selectedFormat === "docx") {
      // For DOCX download - create a downloadable HTML file that can be opened in Word
      const htmlContent = `
        <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word'>
          <head>
            <meta charset='utf-8'>
            <title>${documentTitle}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }
              h1, h2 { color: #333; }
              .signature-section { margin-top: 40px; }
            </style>
          </head>
          <body>
            ${documentContent}
          </body>
        </html>
      `;

      const blob = new Blob([htmlContent], { type: "application/msword" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${documentTitle.replace(/\s+/g, "_")}.doc`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }

    setIsDownloadDialogOpen(false);
    setSelectedFormat("");
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <header className="mb-8">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Smart Document Automation</h1>
          {selectedDocType && (
            <Button variant="outline" size="sm" onClick={handleBack}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to document selection
            </Button>
          )}
        </div>
        {selectedDocType && (
          <div className="mt-2">
            <h2 className="text-xl font-medium">{selectedDocType.title}</h2>
            <p className="text-muted-foreground">
              {selectedDocType.description}
            </p>
          </div>
        )}
      </header>

      {!selectedDocType ? (
        <DocumentTypeSelector onSelect={handleDocTypeSelect} />
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Tabs
                value={activeView}
                onValueChange={(value) =>
                  setActiveView(value as "split" | "questionnaire" | "preview")
                }
              >
                <TabsList>
                  <TabsTrigger value="split">Split View</TabsTrigger>
                  <TabsTrigger value="questionnaire">Questionnaire</TabsTrigger>
                  <TabsTrigger value="preview">Document Preview</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Save className="mr-2 h-4 w-4" />
                Save Draft
              </Button>
              <Dialog
                open={isDownloadDialogOpen}
                onOpenChange={setIsDownloadDialogOpen}
              >
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm" disabled={progress < 100}>
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Download Document</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Select Format:
                      </label>
                      <Select
                        value={selectedFormat}
                        onValueChange={setSelectedFormat}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Choose download format" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="pdf">
                            <div className="flex items-center">
                              <FileText className="mr-2 h-4 w-4" />
                              PDF Format
                            </div>
                          </SelectItem>
                          <SelectItem value="docx">
                            <div className="flex items-center">
                              <FileText className="mr-2 h-4 w-4" />
                              Word Document (.doc)
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex justify-end space-x-2">
                      <Button
                        variant="outline"
                        onClick={() => setIsDownloadDialogOpen(false)}
                      >
                        Cancel
                      </Button>
                      <Button onClick={handleDownload}>
                        <Download className="mr-2 h-4 w-4" />
                        Download
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              <Button variant="outline" size="sm" disabled={progress < 100}>
                <Share2 className="mr-2 h-4 w-4" />
                Share
              </Button>
            </div>
          </div>

          <div className="flex flex-col lg:flex-row gap-6">
            {(activeView === "split" || activeView === "questionnaire") && (
              <Card
                className={`${activeView === "split" ? "lg:w-1/2" : "w-full"}`}
              >
                <CardContent className="p-6">
                  <SmartQuestionnaire
                    documentType={selectedDocType.title}
                    questions={documentConfigs[selectedDocType.id]?.questions}
                    onAnswerChange={handleQuestionnaireUpdate}
                    onComplete={handleQuestionnaireComplete}
                  />
                </CardContent>
              </Card>
            )}

            {(activeView === "split" || activeView === "preview") && (
              <Card
                className={`${activeView === "split" ? "lg:w-1/2" : "w-full"}`}
              >
                <CardContent className="p-6">
                  <DocumentPreview
                    documentTitle={selectedDocType.title}
                    documentContent={generateDocumentContent(questionnaireData)}
                    missingFields={getMissingFields(questionnaireData)}
                  />
                </CardContent>
              </Card>
            )}
          </div>

          <div className="mt-4">
            <div className="flex justify-between text-sm mb-1">
              <span>Document Completion</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2.5">
              <div
                className="bg-primary h-2.5 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Home;
