import React from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  FileText,
  FileSignature,
  FileCheck,
  FileCog,
  ChevronRight,
} from "lucide-react";

interface DocumentType {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
}

interface DocumentTypeSelectorProps {
  onSelect: (documentTypeId: string) => void;
  documentTypes?: DocumentType[];
}

const DocumentTypeSelector: React.FC<DocumentTypeSelectorProps> = ({
  onSelect = () => {},
  documentTypes = [
    {
      id: "nda",
      title: "Non-Disclosure Agreement",
      description:
        "Protect your confidential information when sharing with partners or employees",
      icon: <FileText className="h-8 w-8 text-primary" />,
    },
    {
      id: "service-agreement",
      title: "Service Agreement",
      description:
        "Define the terms and conditions for providing services to clients",
      icon: <FileSignature className="h-8 w-8 text-primary" />,
    },
    {
      id: "employment-contract",
      title: "Employment Contract",
      description:
        "Create legally compliant employment agreements for new hires",
      icon: <FileCheck className="h-8 w-8 text-primary" />,
    },
    {
      id: "operating-agreement",
      title: "Operating Agreement",
      description:
        "Establish the rules and structure for your LLC or business entity",
      icon: <FileCog className="h-8 w-8 text-primary" />,
    },
  ],
}) => {
  return (
    <div className="w-full max-w-6xl mx-auto bg-background p-6 rounded-lg">
      <div className="mb-6">
        <h2 className="text-2xl font-bold">Select Document Type</h2>
        <p className="text-muted-foreground">
          Choose the type of legal document you need to create
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {documentTypes.map((docType) => (
          <Card
            key={docType.id}
            className="cursor-pointer hover:border-primary transition-colors"
            onClick={() => onSelect(docType.id)}
          >
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="p-2 rounded-md bg-primary/10">
                  {docType.icon}
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </div>
              <CardTitle className="mt-4 text-lg">{docType.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>{docType.description}</CardDescription>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-8 flex justify-center">
        <Button variant="outline" className="mr-2">
          Browse All Templates
        </Button>
        <Button variant="ghost">Request Custom Template</Button>
      </div>
    </div>
  );
};

export default DocumentTypeSelector;
